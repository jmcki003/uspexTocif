function doneOr = checkStatus_local(jobID)
%--------------------------------------------------------------------
%This routine is to check if the submitted job is done or not
%One needs to do a little edit based on your own case.
%1   : whichCluster (0: no-job-script, 1: local submission, 2: remote submission)
%--------------------------------------------------------------------

%We cannot check job by ID alone. So instead check your username, JobID, and then print the state of this job
    [a,b] = unix(['qstat -u jessica | grep ' jobID ' | awk ''{print $5}'' ']);

%Step2: to find the keywords from screen message to determine if the job is done
%Below is just a sample:
%-------------------------------------------------------------------------------
%Job id                    Name             User            Time Use S Queue
%------------------------- ---------------- --------------- -------- - -----
%2455453.nano              USPEX            qzhu            02:28:42 R cfn_gen04 
%-------------------------------------------------------------------------------
%This is how it shows on the producer's cluster.

%job-ID  prior   name       user         state submit/start at     queue                  slots ja-task-ID 
%---------------------------------------------------------------------------------------------------------
%2105118 0.51000 x_2000.sh  dnocito      dr    04/10/2015 18:06:15 all.q@n0001.chem.int          1
%---------------------------------------------------------------------------------------------------------
%This is how ours looks.


%If there is no key words like 'R/Q Cfn_gen04', it indicates the job is done.
    if (1 == strcmp(b,'r')) | (1 == strcmp(b,'t')) | (1 == strcmp(b,'qw'))
       doneOr = 0;  
    else
       doneOr = 1;
       unix('rm USPEX*');    % to remove the log file
    end
