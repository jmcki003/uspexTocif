function jobNumber = submitJob_local()
%-------------------------------------------------------------
%This routine is to check if the submitted job is done or not
%One needs to do a little edit based on your own case.

%1   : whichCluster (default 0, 1: local submission, 2: remote submission)
%-------------------------------------------------------------

%Step 1: to prepare the job script which is required by your supercomputer
%[ignore,pwd]=unix(['echo ${PBS_O_WORKDIR}'])

fp = fopen('myrun.sh', 'w');    
fprintf(fp, '#!/bin/sh\n');
fprintf(fp, '\n');
fprintf(fp, '#$ -cwd\n');
fprintf(fp, '#$ -pe lammpi 1\n');
fprintf(fp, '#$ -N USPEX\n');
fprintf(fp, '\n');
fprintf(fp, 'ksh ./tinker.sh\n');
fclose(fp);

%Step 2: to submit the job with the command like qsub, bsub, llsubmit, .etc.
%It will output some message on the screen like '2350873.nano.cfn.bnl.local'
[a,b]=unix(['qsub myrun.sh']);


%Step 3: to get the jobID from the screen message
end_marker = findstr(b,'("');
start_marker = findstr(b,'job');
jobNumber = b(start_marker(1)+4:end_marker(1)-2); 
  
