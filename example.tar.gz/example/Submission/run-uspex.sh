#!/bin/sh



while true
do
   date >> log 
   matlab < USPEX.m >> log
   sleep 300
done
